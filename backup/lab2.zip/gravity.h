/* Sooyoung Jeon */

/*
 * Definde the constatn gravity
 */
#define GRAVITY -32.17405
