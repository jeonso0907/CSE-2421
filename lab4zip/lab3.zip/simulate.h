/* Sooyoung Jeon */

void run_simulate(struct Sim *s);
