/* Sooyoung Jeon */

#include "func.h"
#include <stdio.h>

/*
 * Creates the prototypes to test
 */
int main() {

	double x = get_x(3.0, 4.5, 0.0075);
	printf("%.2lf\n", x);

	return 0;
}
