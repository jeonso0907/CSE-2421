
/* SP21 Lab 6 Insctructor supplied code.  Not for outside disclosure
 * Copyright 2021 Neil Kirby
 * Do not remove this copyright notice.
 */

struct Device
{	
	char name[20];
	short adjustments[8];
	short avg;
};

