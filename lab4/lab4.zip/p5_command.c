/* 
 * Sooyoung Jeon
 * Lab4 (Prototype of command line Function)
 */

int main(int argc, char** argv) {
	
}
